public class OperatorsLecture {
    public static void main(String[] args) {
        //CONCEPTS
        //Arithmetic Operators     +, -, *, /, %
        //Unary Operators         U++ , U-- ,  ++U, --U
        //Realtional Operators    >, <, >=, <= , == !=
        //Ternary Operator        COndition ? True : False
        //Logical Operators       && , || , !
        //Bitwise Operators       %, |, !
        //Shifted Operators       <<, >> , >>>
        //Short Hand Operators     = += -= *= /= %= &= ^= |= <<= >>= >>>=


        //OUTPUT
        System.out.println("----------------------------------------------");
        int a=2;
        int b=2;
        int c=1;
        // System.out.println(a+b);
        // System.out.println(a-b);
        // System.out.println(a*b);
        // System.out.println(a/b);
        // System.out.println(b%a);

        // System.out.println("pre = "+(--a));
        // System.out.println("Post "+(b--));
        // System.out.println(!true);


        // System.out.println(2>=3);
        // System.out.println(a<3);
        // System.out.println(a==b);
        //   boolean bl = (1>3)? ((2>3)?true:false) : ((2<3)?true:false) ;
        // System.out.println(bl);

        // System.out.println(2<3 && (a++)<3);
        // System.out.println(a);
        // // System.out.println(2>3 || 2<3);

        // //Bit wise
        // System.out.println(2>3 & (b++)<3);
        // System.out.println(a);
        // //System.out.println(2>3 | 2<3);

        //Bitwise
        // System.out.println(~1);
        // System.out.println(~2);
        // System.out.println(~3);
        // System.out.println(~4);
        // System.out.println(1|2);
         System.out.println(2^3);
        System.out.println(10<<0);
        System.out.println(10<<1);
        System.out.println(10<<2);
        System.out.println(10<<3);
        System.out.println(10<<4);
        System.out.println(10>>1);
        System.out.println(10>>2);
        System.out.println(10>>3);
        //System.out.println(-10>>>5);
        System.out.println(-(10>>6));

       // System.out.println(2|3);


        System.out.println("\n----------------------------------------------");
    }
}
