class DataTypesLecture{
     
    int myLocal = 2;
    // void my(){
      //    myLocal=3;
     // }
     
      public static void main(String abc[]) {
      int myLocal = 35;
      /* System.out.print("Hello G");
      System.out.println("Hello G");
      System.out.print("Hello G");
      */
      //   int num1 = 1;
      //   int num2 = 2;
      System.out.println("--------------------------------");
      boolean result = true ;
      //   System.out.println(num1);
        long num1 = 1934567899976543433L;
          //int num2=3.5;
         byte bt = 127;
         short sh = 12723;
        
         float f2 = 10.56f;
         double db = 100.67777;
         //type casting
         //up type casting
         double db1 =  10.45f; 
         float f1 = 1;
         char ch= 'A';
         char ch1= 'a';
         char ch3= 'z';
         //down type casting
         int num2 = (int) num1;
         int num3 = (int) ch;
         int num4 = (int) ch1;
         int num5 = (int) ch3;
         String st = "New String";
         String st1 = " New String";
         System.out.println(num3);
         System.out.println(num4);
         System.out.println(num5);
         System.out.print(ch+" ");
         System.out.println(st+st1);
         //myLocal=3;
         System.out.print(myLocal);
      //   System.out.println(bt);
      //   System.out.println(sh);
      //   System.out.println(f1);
      //   System.out.println(f2);
      //   System.out.println(db);
      //   System.out.println(db1);
           
      //ABcdEF = //ABCDEF
      System.out.println("\n--------------------------------");
     }

   
}